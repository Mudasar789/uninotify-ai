# UniNotify MVP

Automated university admission notifier using AI and Google Sheets.